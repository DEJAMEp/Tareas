function traerEstudiantes(){
    fetch("lista2020.json")
        .then(respuesta => respuesta.json())
        .then(datosEst =>{
            console.log("dataEst", datosEst);
        });
};
