function Guardar(){
    var input = document.getElementById("inputuno").value;
    localStorage.setItem("texto",texto1);
    document.getElementById("btn btn-primary").innerHTML=localStorage.getItem("texto")
}