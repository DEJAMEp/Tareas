var edad=parseInt(prompt("Ingrese su edad"));
while(edad < 100){
    var edad= edad=parseInt(prompt("Ingrese su edad"));
    if (edad == 0) {
        break;
}
    if (edad >= 18) {
        document.write(edad + " sos mayor" + "<br>")
    }
}