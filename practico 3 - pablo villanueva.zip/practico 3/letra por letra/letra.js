var string = prompt("inggrese")
for (letter of string){
    document.write(letter + "<br>")
}


