var num1=1
var numeros=[1,2,3,4,5,6,7,8,9,10];

for(num1; num1<=10; num1++){
    if(num1==6)
    break;
    document.write(num1)
}
document.write("<br>")