var num=[0,1,2,3,4,6,7,8,9,10];

for(numero of num){
    if (numero %2==0){
    alert(numero + "es par")
}else{
    alert(numero + "es inpar")
}
};

