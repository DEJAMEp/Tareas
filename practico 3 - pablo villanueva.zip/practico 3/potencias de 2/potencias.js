var num =2
while(num<10000){
    document.write(num + "*2= ")
    document.write(num + "<br>")
    num=num*2;
}