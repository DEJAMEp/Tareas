import React from "react";
import { Link } from "react-router-dom";
 const Header=({itemsCarrito,itemsFavorito})=>{
     return(
         <header>
             <div className="titulo-header">
                 <Link  style={{textDecoration: 'none',color:'black'}}to='/'><span>Proyecto Final - Modulo</span>  <img className="App-logo" src='https://cdn-icons-png.flaticon.com/128/1126/1126012.png'width='40px'/></Link>
             </div>

             <div className='link'>
                 <ul>
                     <li>
                         <Link  style={{textDecoration: 'none',color:'black'}}to='/'>Home</Link>
                     </li>
                     <li>
                         <Link  style={{textDecoration: 'none',color:'black'}}to='/'>Sing in</Link>
                     </li>
                     <li>
                         <Link  style={{textDecoration: 'none',color:'black'}}to='/carrito'>
                             <img src='https://cdn-icons.flaticon.com/png/128/2662/premium/2662503.png?token=exp=1638965330~hmac=d88c59c92096adcee2d722c962a8e0da'/>
                             <span>{itemsCarrito.length  ===0?"":itemsCarrito.length}</span>
                         </Link>
                     </li>
                     <li>
                         <Link  style={{textDecoration: 'none',color:'black'}}to='/favorito'><img src="https://cdn-icons.flaticon.com/png/128/2550/premium/2550357.png?token=exp=1639101300~hmac=62d9a780df231668d5ae8dfc9a3d58e5"/>
                            <span>{itemsFavorito.length  ===0?"":itemsFavorito.length}</span>
                         </Link>
                     </li>
                 </ul>
             </div>
         </header>
     )
 }
 export default Header;