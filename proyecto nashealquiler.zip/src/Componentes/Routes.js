import React from 'react'
import {  Routes, Route, Link } from 'react-router-dom'
import Carrito from './Carrito'
import Favoritos from './Peliculas/Favoritos'
import Productos from './Peliculas/Productos'
import Estreno from './Peliculas/Estrenos'
import Ranking from './Peliculas/Ranking'
import NavPeliculas from './navPeliculas'

import AsideFavoritos from'./asideFavoritos'

export default function Rout({itemProductos,itemsCarrito, agregarCarrito,restarCarrito,limpiarCarrito,itemsFavorito,limpiarFavorito,agregarFavorito,restarFavorito,itemsEstreno,itemsRanking,itemsAside}) {
    
    return (
        <div>
            <Routes>
                <Route path='/' element={
                <div className='peliculas'>
                    
                    <div className='contenedor-productos'>
                        <div className='productos'>
                            <div>
                                <NavPeliculas/>
                                <Productos itemProductos={itemProductos} agregarCarrito={agregarCarrito}agregarFavorito={agregarFavorito}/>
                            </div>
                            <AsideFavoritos itemsAside={itemsAside}/>
                        </div>
                    </div>
                </div>
            }>
                
                </Route>
                <Route path='/estrenos' element={
                <div className='peliculas'>
                    
                    <div className='contenedor-estrenos'>
                        <div className='estrenos'>
                            <div>
                                <NavPeliculas/>
                                <Estreno itemEstreno={itemsEstreno} agregarCarrito={agregarCarrito}agregarFavorito={agregarFavorito}/>
                                </div>
                            <AsideFavoritos itemsAside={itemsAside}/>
                        </div>
                    </div>
                </div>
                }>                
                </Route> 

                <Route path='/ranking' element={
                    <div className='peliculas'>
                        
                        <div className='contenedor-ranking'>
                                <div className='ranking'>
                                    <div>
                                        <NavPeliculas/>
                                        <Ranking itemsRanking={itemsRanking} agregarCarrito={agregarCarrito}agregarFavorito={agregarFavorito}/>                          
                                    </div> 
                                    <AsideFavoritos itemsAside={itemsAside}/>   
                                </div>
                        </div>
                      </div>
                }>
                </Route>

                <Route path='/carrito' element={
                    <div className='contenedor-carrito'>
                        <Carrito itemsCarrito={itemsCarrito} agregarCarrito={agregarCarrito} restarCarrito={restarCarrito} limpiarCarrito={limpiarCarrito}/>
                    </div>
                }>
                </Route>
                <Route path='/favorito' element={
                    <div className='contenedor-favorito'>
                        <Favoritos itemsFavorito={itemsFavorito} limpiarFavorito={limpiarFavorito}agregarFavorito={agregarFavorito} restarFavorito={restarFavorito}/>
                    </div>
                }>
                </Route>
            </Routes>
            
        </div>
    )
}