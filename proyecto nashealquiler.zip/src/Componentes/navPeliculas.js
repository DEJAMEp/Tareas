import React from'react';
import {Link} from 'react-router-dom'

const NavPeliculas=()=>{
    return(
        <div className='contenedor-navPeliculas'>
            <div className='NavPeliculas'>
                <h1>Peliculas</h1>
                <ul>
                    <li><Link style={{textDecoration: 'none',color:'white'}} to='/'>Ultimas Agregadas</Link></li>
                    <li><Link style={{textDecoration: 'none',color:'white'}} to='/estrenos'>Estreno</Link></li>
                    <li><Link style={{textDecoration: 'none',color:'white'}} to='/ranking'>Ranking</Link></li>
                </ul>
            </div>
            <input type='search' placeholder='Busca aqui el nombre de tu pelicula' style={{color:'black'}}/>
        </div>    
    )
}
export default NavPeliculas;