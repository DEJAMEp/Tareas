import React from 'react'
const Estreno = ({ itemEstreno, agregarCarrito, agregarFavorito }) => {
    return (
    <>
        <div className='contenedor-carta'>
            {
                itemEstreno.map((itemProducto) => (
                    <div className='carta'>
                       <h4>{itemProducto.nombre}</h4>
                        <img src={itemProducto.poster}/>
                        <h5><span>xDia</span> ${itemProducto.precio}</h5>
                        <h5>{itemProducto.rating}</h5>
                        <div className='botones-carta'>
                        <button onClick={()=>agregarCarrito(itemProducto)}><img src='https://cdn-icons.flaticon.com/png/128/2662/premium/2662503.png?token=exp=1638965330~hmac=d88c59c92096adcee2d722c962a8e0da'/></button>
                            <button onClick={()=>agregarFavorito(itemProducto)}><img src='https://cdn-icons-png.flaticon.com/128/57/57039.png'/></button>
                        </div>
                    </div>
                ))
            }
        </div>
    </>
    )
}
export default Estreno