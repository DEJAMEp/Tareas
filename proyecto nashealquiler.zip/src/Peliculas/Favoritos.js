
import React from 'react'

const Favoritos= ({itemsFavorito,limpiarFavorito,restarFavorito})=>{
    return(
        <div className='favoritos'>
        <div className='cabecera-itemsFavorito'>
            <span>Favorito</span>
                {itemsFavorito.length >=1 && (
                    <button onClick={limpiarFavorito}>Limpiar Favorito</button>
                )}
            </div>
        <div className='contenedor-itemFavorito'>
            
            {itemsFavorito.length === 0 &&(<div>No hay items en el Favorito berraco, comprate algo </div>)}
            {
                itemsFavorito.map((item)=>(
                    
                    <div key={item.id} className='itemFavorito'>
                       <img src={item.poster} alt={item.name}/>
                       <ul>
                            <li><b>Nombre: </b>{item.nombre}</li>
                            <li><b>Genero: </b>{item.genero}</li>
                            <li><b>Ranking: </b>{item.rating}</li>
                        </ul>
                       <div className='btn-favorito'>
                           <button onClick={()=>restarFavorito(item)}><img src='https://cdn-icons-png.flaticon.com/512/1828/1828595.png'/></button>
                       </div>
                    </div>
                ))
            }
        </div>
        </div>
    )
}
export default Favoritos;