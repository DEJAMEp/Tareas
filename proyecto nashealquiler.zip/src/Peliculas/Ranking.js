import React from 'react'
import Slider from '../Slider'

const Ranking=({itemsRanking, agregarCarrito,agregarFavorito})=>{
    return(
        <>
        <div className='contenedor-carta'>
            {
                itemsRanking.map((itemProducto)=>(
                    <div className='carta'>
                        <h6>{itemProducto.nombre}</h6>
                        <img src={itemProducto.poster}/>
                        <h5><span>xDia</span> ${itemProducto.precio}</h5>
                        <h5>{itemProducto.rating}</h5>
                        <div className='botones-carta'>
                        <button onClick={()=>agregarCarrito(itemProducto)}><img src='https://cdn-icons-png.flaticon.com/128/2438/2438133.png'/></button>
                            <button onClick={()=>agregarFavorito(itemProducto)}><img src='https://cdn-icons-png.flaticon.com/128/57/57039.png'/></button>
                        </div>
                    </div>
                ))
            }
        </div>
        </>
    )
}
export default Ranking