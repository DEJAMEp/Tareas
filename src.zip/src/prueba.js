import React from 'react';

import "./index.css"

function Prueba(props){
    return(
        <main>
            <div className="card">
                <img className="contenido" src={props.imagen} alt='planta'/>
                    <p className="nombre">{props.nombre}</p>
                    <p className="GENERO"> {props.genero}</p>
                    <p className="rating"> {props.Rancking}</p>
                    <p className="precio"> {props.valor}</p>
            </div>
        </main>
    )
}
const CAP = {"pelis": [
    {
        "id":"1",
        "nombre": "Son como Niños",
        "Lanzamiento": 2006,
        "genero": "comedia",
        "actores": "Adam Sandler (Lenny Feder), Kevin James (Eric Lamonsoff), Salma Hayek (Roxanne Chase-Feder) y David Spade (Marcus Higgins)",
        "imagen":"https://pics.filmaffinity.com/Son_como_ni_os-567297059-large.jpg",
        "Director": "Dennis Dugan",
        "Rancking": "5",
        "valor": "500$"
    },
    
   
    {   "id":"2",
        "nombre": "Raya y el último dragón",
        "Lanzamiento": 2021,
        "genero": "animacion",
        "actores": "Awkwafina(Sisu) y Kelly Marie Tran (Raya)",
        "imagen":"https://pics.filmaffinity.com/Raya_y_el_ltimo_drag_n-458441308-large.jpg",
        "Director": "Carlos López Estrada, Don Hall",
        "Rancking": "4"
    },
      
    {
        "id":"3",
        "nombre": "Oxígeno",
        "Lanzamiento": 2021,
        "genero": "suspenso",
        "actores": "Mélanie Laurent, Malik Zidi, Marc Saez, Eric Herson-Macarel",
        "imagen":"https://imagenes.gatotv.com/categorias/peliculas/posters/oxigeno.jpg",
        "Director": "Alexandre Aja",
        "Rancking": "4"
       
    },
    
    {
        "id":"4",
        "nombre": "Mujer Maravilla 1984",
        "Lanzamiento": 2020,
        "genero": "scifi",
        "actores": "Gal Gadot (Diana) y  Kristen Wiig (Cheetah)",
        "imagen":"https://i.pinimg.com/originals/60/50/a7/6050a74fecf04ac8f27ccb4b11af5863.jpg",
        "Director": "Patty Jenkins",
        "Rancking": "4"
    },
    {    "id":"5",
         "nombre": "Step Up Revolution",
        "Lanzamiento": 2012,
        "genero": "drama",
        "actores": "Ryan Guzman (Sean) y Kathryn McCormick (Emily)",
        "imagen":"https://m.media-amazon.com/images/I/813ISifTeML._SL1500_.jpg",
        "Director": "Scott Speer",
        "Rancking": "4"
    },
    {   "id":"6",
         "nombre": "Distancia de rescate ",
        "Lanzamiento": 2021,
        "genero": "crimen",
        "actores": "María Valverde, Dolores Fonzi, Guillermo Pfening, ",
        "imagen":"https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRkY-JrCiVwH-JL0xg0KUw55MGGshiOx1QWPsoaBRqWFo3rFIFu",
        "Director": "Claudia Llosa",
        "Rancking": "9"
    },
    {    "id":"7",
        "nombre": "Mudanza Mortal ",
        "Lanzamiento": 2021,
        "genero": "terror",
        "actores": "Ashley Greene",
        "imagen":"https://1.bp.blogspot.com/-b3HQMMX6_lo/YPWEAPbe8OI/AAAAAAAADP0/58TmX08t-lwr-fR2DRGB8MrtYBFNJHhVQCLcBGAsYHQ/s1200/mudanza-mortal%2Bposter.jpeg",
        "Director": "Peter Winther",
        "Rancking": "7"
        
    },
    {
        "id":"8",
        "nombre": "Bajo cero ",
        "Lanzamiento": 2021,
        "genero": "suspenso",
        "actores": "Javier Gutiérrez, Karra Elejalde, Luis Callejo",
        "imagen":"https://i2.wp.com/noescinetodoloquereluce.com/wp-content/uploads/2020/07/bajocero.jpg?resize=800%2C1134&ssl=1",
        "Director": "Lluís Quílez",
        "Rancking": "4"
    },   
    {
        "id":"9",
        "nombre": "Sky Rojo",
        "Lanzamiento": 2021,
        "genero": "niños",
        "actores": "Peri Baumeister, Alexander Scheer, Graham McTavish",
        "imagen":"http://todotvnews.com/wp-content/uploads/2021/03/poster-sky-rojo.jpg",
        "Director": " Peter Thorwarth",
        "Rancking": "6"
    },
    {
        "id":"10",
        "nombre": "JOBS",
        "Lanzamiento": 2013,
        "genero": "documentales",
        "actores": "Michael Fassbender (Steve Jobs)",
        "imagen":"https://i.blogs.es/011895/cartel_documental/1366_2000.jpg",
        "Director":  "Danny Boyle",
        "Rancking": "5"
    }
]
}

function Lista(datos){
    return(
        <>
        {datos.array.map((planta)=>{
            const {nombre, imagen,precio,genero,Rancking}= planta;
            return(
                <Prueba nombre={nombre} imagen=
                {imagen} key={precio} genero={genero} rating={Rancking}/>
            )
            
         })}    
    
        </>
    )
}

export default function App(){
    return(
        <Lista array={CAP}/>
    )
}