


// guardar datos
   // localStorage.setItem("nombre", "dato");

 // leer datos
    //var miDato = localStorage.getItem("#name");
