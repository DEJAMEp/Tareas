var botonguardar = document.getElementById("boton");
var usuario=[];
function guardardatos(){
   var nombre = document.getElementById("name").value;
function usuarios(nombre){
      this.nombre=nombre;
   };
var usuarioins = new usuarios(nombre);
usuario.push(usuarioins);
console.log(usuarioins)
};
botonguardar.addEventListener("click",guardardatos);




//document.getElementById("btn btn-primary").innerHTML=localStorage.getItem("texto")

  //document.getElementById("boton").addEventListener("click",store)
  //store();


// guardar datos
   // localStorage.setItem("nombre", "dato");

 // leer datos
    //var miDato = localStorage.getItem("#name");
